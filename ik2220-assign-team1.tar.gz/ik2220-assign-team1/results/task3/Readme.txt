All the results will be printed on to the console as our approach is completely automated
